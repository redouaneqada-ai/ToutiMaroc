@echo off
setlocal
set "APP_HOME=%~dp0"
set "GRADLE_VERSION=8.7"
if defined GRADLE_USER_HOME (set "GRADLE_HOME_BASE=%GRADLE_USER_HOME%\wrapper\dists\manual-gradle-%GRADLE_VERSION%") else (set "GRADLE_HOME_BASE=%USERPROFILE%\.gradle\wrapper\dists\manual-gradle-%GRADLE_VERSION%")
set "GRADLE_BIN=%GRADLE_HOME_BASE%\gradle-%GRADLE_VERSION%\bin\gradle.bat"
if not exist "%GRADLE_BIN%" (
  if not exist "%GRADLE_HOME_BASE%" mkdir "%GRADLE_HOME_BASE%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_HOME_BASE%\gradle-%GRADLE_VERSION%-bin.zip'; Expand-Archive -Force '%GRADLE_HOME_BASE%\gradle-%GRADLE_VERSION%-bin.zip' '%GRADLE_HOME_BASE%'"
)
call "%GRADLE_BIN%" -p "%APP_HOME%" %*
exit /b %ERRORLEVEL%
