package com.example.touti;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.graphics.Color;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  getWindow().setStatusBarColor(Color.rgb(5,54,36));
  getWindow().setNavigationBarColor(Color.rgb(5,54,36));
  WebView w=new WebView(this); w.setBackgroundColor(Color.rgb(5,54,36));
  WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
  w.loadUrl("file:///android_asset/index.html"); setContentView(w);
 }
}
